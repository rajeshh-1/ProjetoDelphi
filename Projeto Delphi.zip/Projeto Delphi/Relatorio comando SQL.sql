-- Relatorio comando SQL
SELECT Cidades.Cod_Cidade
      ,Cidades.NomeCidade
      ,Cidades.Estado
      ,Cidades.Cep_Inicial
      ,Cidades.Cep_Final
      ,Clientes.Cod_Cliente
      ,Clientes.CGC_CPF_Cliente
      ,Clientes.NomeCliente
      ,Clientes.Telefone
      ,Clientes.Endereco
      ,Clientes.Bairro
      ,Clientes.Complemento
      ,Clientes.E_mail
      ,Clientes.Cep
FROM Cidades
INNER JOIN Clientes ON Clientes.Cod_Cidade = Cidades.Cod_Cidade
WHERE Cidades.Cod_Cidade   BETWEEN 0 and 999999  -- filtros preenchidos no Delphi
  and Clientes.Cod_Cliente BETWEEN 0 and 999999  
  and Cidades.Estado       BETWEEN 'AA' and 'ZZ'
ORDER BY Clientes.Cod_Cidade


