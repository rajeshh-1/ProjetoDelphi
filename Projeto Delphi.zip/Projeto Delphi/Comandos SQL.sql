CREATE DATABASE Testesinquia
GO

USE Testesinquia;
GO

-- Cria��o das Tabelas 
-- Cidades
CREATE TABLE dbo.Cidades(
    Cod_Cidade Integer Identity not null,
    NomeCidade Varchar(100),
    Estado Char(2),
    Cep_Inicial Varchar(8),
    Cep_Final Varchar(8),

	Constraint pkCidade Primary Key (Cod_Cidade)
);
GO

-- Clientes
CREATE TABLE dbo.Clientes(
    Cod_Cliente Integer identity not null,
    CGC_CPF_Cliente Varchar(11), 
    NomeCliente Varchar(100),
    Telefone Varchar(11),
    Endereco Varchar(100),
    Bairro Varchar(50),
    Complemento Varchar(50),
    E_mail Varchar(100),
    Cod_Cidade Integer,
    Cep Varchar(8),
    
	constraint pkCliente primary key (Cod_Cliente),
	constraint fkCliente_Cidade foreign key (Cod_Cidade) references dbo.Cidades(Cod_Cidade));

-- Populando a tabela de Cidades com registros
INSERT INTO dbo.Cidades (NomeCidade, Estado, Cep_Inicial, Cep_Final)
VALUES ('S�o Paulo', 'SP', '00000001', '00000010');

INSERT INTO dbo.Cidades (NomeCidade, Estado, Cep_Inicial, Cep_Final)
VALUES ('Rio de Janeiro', 'RJ', '00000011', '00000020');

INSERT INTO dbo.Cidades (NomeCidade, Estado, Cep_Inicial, Cep_Final)
VALUES ('Marilia', 'SP', '00000021', '00000030');

INSERT INTO dbo.Cidades (NomeCidade, Estado, Cep_Inicial, Cep_Final)
VALUES ('Tupa', 'SP', '00000031', '00000040');
GO

-- Populando a tabela de Clientes com registros
INSERT INTO dbo.Clientes (CGC_CPF_Cliente, NomeCliente, Telefone, Endereco, Bairro, Complemento, E_mail, Cod_Cidade, Cep)
VALUES ('12345678901', 'Antonio Carlos', '11923344545', 'Rua A, 123', 'Centro', 'Apto 101', 'fulano@example.com', 1, '00000001');

INSERT INTO dbo.Clientes (CGC_CPF_Cliente, NomeCliente, Telefone, Endereco, Bairro, Complemento, E_mail, Cod_Cidade, Cep)
VALUES ('98765432109', 'Luciano Da Silva', '99887766558', 'Avenida B, 456', 'Bairro X', 'Casa 2', 'ciclano@example.com', 2, '00000011');

INSERT INTO dbo.Clientes (CGC_CPF_Cliente, NomeCliente, Telefone, Endereco, Bairro, Complemento, E_mail, Cod_Cidade, Cep)
VALUES ('11122233344', 'Gabriel Stangari', '55443322118', 'Rua C, 789', 'Zona Sul', 'Sala 3', 'beltrano@example.com', 3, '00000021');

INSERT INTO dbo.Clientes (CGC_CPF_Cliente, NomeCliente, Telefone, Endereco, Bairro, Complemento, E_mail, Cod_Cidade, Cep)
VALUES ('55544433322', 'Maria Souza', '66778899008', 'Avenida D, 321', 'Bairro Y', 'Bloco 4', 'maria@example.com', 4, '00000031');


-- CONHECIMENTO DE COMANDOS SQL.
-- 1. Criar um comando SELECT que retorne APENAS o nome dos clientes da cidade �TUPA�. Utilizar o EXISTS para realizar a condi��o.
SELECT Cod_Cliente
      ,NomeCliente
      ,Cod_Cidade
FROM dbo.Clientes
WHERE EXISTS (
    SELECT *
    FROM dbo.Cidades
    WHERE Clientes.Cod_Cidade = Cidades.Cod_Cidade
    AND Cidades.NomeCidade = 'TUPA' );

-- 2. Criar um comando SELECT que retorne o nome do cliente e o nome da cidade de todos os registros
SELECT Clientes.NomeCliente
	  ,Cidades.NomeCidade
FROM dbo.Clientes
INNER JOIN dbo.Cidades ON Clientes.Cod_Cidade = Cidades.Cod_Cidade;

-- 3. Criar um comando SELECT que retorne TODOS os nomes e os c�digos dos clientes ordenados por nome do cliente
SELECT Cod_Cliente
      ,NomeCliente
FROM dbo.Clientes
ORDER BY NomeCliente;

-- 4. Criar um comando DELETE que exclua clientes com c�digo do cliente entre a numera��o 100 e 200.
DELETE FROM dbo.Clientes
WHERE Cod_Cliente BETWEEN 100 AND 200;

-- 5. Criar um comando UPDATE que altere o estado de todas as cidades para o estado �SP� quando estiverem com estado igual a �PR�.
UPDATE dbo.Cidades
SET Estado = 'SP'
WHERE Estado = 'PR';

-- 6. Criar um comando INSERT na tabela de clientes de um registro qualquer com todos os campos da tabela. (valores livres)
INSERT INTO dbo.Clientes (CGC_CPF_Cliente, NomeCliente, Telefone, Endereco, Bairro, Complemento, E_mail, Cod_Cidade, Cep)
VALUES ('98765432109', 'Ana Silva', '1122334455', 'Rua Principal, 789', 'Centro', 'Casa 3', 'ana@example.com', 2, '54321098');