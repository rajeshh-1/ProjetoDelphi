-- 7. Criar uma view para consultar os registros contidos na tabela CIDADES. (Criar um arquivo separado)
CREATE VIEW dbo.ViewCidades AS
SELECT Cod_Cidade
      ,NomeCidade
      ,Estado
      ,Cep_Inicial
      ,Cep_Final
FROM dbo.Cidades;
