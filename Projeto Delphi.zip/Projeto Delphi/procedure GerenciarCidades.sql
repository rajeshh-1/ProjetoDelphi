-- 8. Criar um procedimento armazenado (procedure) para realizar as opera��es de INSERT,
-- UPDATE E DELETE na tabela de CIDADES. Criar uma procedure �nica que fa�a todas as
-- opera��es. Ela pode ser usada no aplicativo criado, se desejar. (Criar um arquivo separado)

CREATE PROCEDURE dbo.GerenciarCidades (
    @Operacao VARCHAR(10),
    @Cod_Cidade INT = NULL,
    @NomeCidade VARCHAR(100) = NULL,
    @Estado CHAR(2) = NULL,
    @Cep_Inicial VARCHAR(8) = NULL,
    @Cep_Final VARCHAR(8) = NULL
)
AS
BEGIN
    IF @Operacao = 'INSERT'
    BEGIN
        INSERT INTO dbo.Cidades (NomeCidade, Estado, Cep_Inicial, Cep_Final)
        VALUES (@NomeCidade, @Estado, @Cep_Inicial, @Cep_Final);
    END
    ELSE IF @Operacao = 'UPDATE'
    BEGIN
        UPDATE dbo.Cidades
        SET NomeCidade = @NomeCidade,
            Estado = @Estado,
            Cep_Inicial = @Cep_Inicial,
            Cep_Final = @Cep_Final
        WHERE Cod_Cidade = @Cod_Cidade;
    END
    ELSE IF @Operacao = 'DELETE'
    BEGIN
        IF EXISTS (SELECT 1 FROM dbo.Clientes WHERE Cod_Cidade = @Cod_Cidade)
        BEGIN
            RAISERROR('N�o � poss�vel excluir a cidade pois existem registros de clientes vinculados a ela.', 16, 1);
            RETURN;
        END
        
        DELETE FROM dbo.Cidades
        WHERE Cod_Cidade = @Cod_Cidade;
    END
    ELSE
    BEGIN
        RAISERROR('Opera��o inv�lida.', 16, 1);
    END
END;
GO

-- Exemplo de utiliza��o da procedure
EXEC GerenciarCidades 'INSERT', NULL, 'Nova Cidade', 'SP', '12345000', '12345999';
GO

EXEC GerenciarCidades 'UPDATE', 1, 'Cidade Alterada', 'PR', '98765000', '98765999';
GO

EXEC GerenciarCidades 'DELETE', 1;
GO
